﻿Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public Class SouthAfrica
    Inherits Country

    'Variable declaration
    Private _SocialGrant As Double

    'property methods
    Public Property SocialGrant() As Double

        Get
            Return _SocialGrant

        End Get
        Set(value As Double)

            _SocialGrant = value

        End Set
    End Property

    'constructor
    Public Sub New(name As String)
        MyBase.New(name)


    End Sub

    Public Overrides Function CalcAveragePeopleNotInNeed() As Double

        Return (CDbl(Population / Population - NumOfAdultsInNeed - NumOfChildrenInNeed))

    End Function

    Public Overrides Function DetermineTrend() As String
        Dim response As String
        If (NumOfPeopleNeededHelpPrevYear > (NumOfChildrenInNeed + NumOfAdultsInNeed)) Then
            response = "Extremely eradicating poverty"
        Else
            response = "Not eradicating poverty and hunger"
        End If

        Return response
    End Function

    Public Function CalcAveSocialGrantReceivers() As Double
        Return (CDbl(Population / (NumOfAdultsInNeed + NumOfChildrenInNeed)))
    End Function

    Public Overrides Function Display() As String
        Dim Tempdisplay As String

        Tempdisplay = "South Africa" & Environment.NewLine
        Tempdisplay &= MyBase.Display
        Tempdisplay &= "Social Grant :" & CStr(_SocialGrant) & Environment.NewLine
        Tempdisplay &= "Average People Not In Need :" & CStr(CalcAveragePeopleNotInNeed()) & Environment.NewLine
        Tempdisplay &= "Trend :" & CStr(DetermineTrend()) & Environment.NewLine
        Tempdisplay &= "Average Social Grant Receivers :" & CStr(CalcAveSocialGrantReceivers()) & Environment.NewLine

        Return Tempdisplay
    End Function

End Class
