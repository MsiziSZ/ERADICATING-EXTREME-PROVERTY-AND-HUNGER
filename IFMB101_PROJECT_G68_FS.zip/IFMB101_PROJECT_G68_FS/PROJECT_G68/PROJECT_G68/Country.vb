﻿Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public MustInherit Class Country

    'Variable declaration
    Private _CountryName As String
    Private _NumOfChildrenInNeed As Integer
    Private _NumOfAdultsInNeed As Integer
    Private _Population As Integer
    Private _NumOfPeopleNeededHelpPrevYear As Integer

    'Property Methods
    Public Property CountryName() As String
        Get
            Return _CountryName

        End Get
        Set(value As String)

            _CountryName = value

        End Set
    End Property

    Public Property NumOfChildrenInNeed() As Integer
        Get
            Return _NumOfChildrenInNeed

        End Get
        Set(value As Integer)

            _NumOfChildrenInNeed = value

        End Set
    End Property

    Public Property NumOfAdultsInNeed() As Integer
        Get
            Return _NumOfAdultsInNeed

        End Get
        Set(value As Integer)

            _NumOfAdultsInNeed = value

        End Set
    End Property

    Public Property Population() As Integer
        Get
            Return _Population

        End Get
        Set(value As Integer)

            _Population = value

        End Set
    End Property

    Public Property NumOfPeopleNeededHelpPrevYear() As Integer
        Get
            Return _NumOfPeopleNeededHelpPrevYear


        End Get
        Set(value As Integer)

            _NumOfPeopleNeededHelpPrevYear = value

        End Set
    End Property

    'constructor
    Public Sub New(name As String)

        _CountryName = name

    End Sub

    'Must override function to calculate average rate of employeed people
    Public MustOverride Function CalcAveragePeopleNotInNeed() As Double
    Public MustOverride Function DetermineTrend() As String

    Public Overridable Function Display() As String
        Dim TempDisplay As String
        TempDisplay = "Country Name :" & _CountryName & Environment.NewLine
        TempDisplay &= "Total Childern In Need Of Help :" & CStr(_NumOfChildrenInNeed) & Environment.NewLine
        TempDisplay &= "Total Adults In Need Of Help :" & CStr(_NumOfAdultsInNeed) & Environment.NewLine
        TempDisplay &= "Population :" & CStr(_Population) & Environment.NewLine
        TempDisplay &= "People Who Needed Help In 2021 :" & CStr(_NumOfPeopleNeededHelpPrevYear) & Environment.NewLine

        Return TempDisplay
    End Function

End Class
