﻿' *****************************************************************
' Team Number: 68
' Team Member 1 Details: Zondo, LT (217089546)
' Team Member 2 Details: Mofolo, M (222073166)
' Team Member 3 Details: Simelane, LM (222098767)
' Team Member 4 Details: Mphigalale, R (221009607)
' Practical: Team Project
' Class name: Form1(Erradicating Poverty and Hunger)
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Public Class Form1

    Private Countries() As Country
    Private NumCountry As Integer
    Private File As FileStream
    Private BF As BinaryFormatter
    Private Filename As String = "Countries"

    Private Sub btnInput_Click(sender As Object, e As EventArgs) Handles btnInput.Click

        NumCountry += 1
        ReDim Preserve Countries(NumCountry)

        Dim Name As String
        Dim NumOfChildern As Integer
        Dim NumOfAdults As Integer
        Dim Population As Integer
        Dim NumOfPeopleNeededHelpPrevYear As Integer

        Dim choice As Integer
        choice = CInt(InputBox("Choose the Country" & Environment.NewLine & "1. South Africa" & Environment.NewLine & "2. America"))

        Name = InputBox("Enter the name of the country")
        NumOfChildern = CInt(InputBox("Enter the number of children who need of help"))
        NumOfAdults = CInt(InputBox("Enter the number of adults who neeed help"))
        Population = CInt(InputBox("Enter the total population of the country"))
        NumOfPeopleNeededHelpPrevYear = CInt(InputBox("Enter the number of people who got help in 2021"))

        Select Case choice
            Case 1 'South Africa
                Dim SA As SouthAfrica = New SouthAfrica(Name)

                SA.CountryName = Name
                SA.NumOfChildrenInNeed = NumOfChildern
                SA.NumOfAdultsInNeed = NumOfAdults
                SA.Population = Population
                SA.NumOfPeopleNeededHelpPrevYear = NumOfPeopleNeededHelpPrevYear
                SA.SocialGrant = CDbl(InputBox("Enter the social grant amount"))

                'upcasting
                Countries(NumCountry) = SA

            Case 2 'America
                Dim USA As America = New America(Name)

                USA.CountryName = Name
                USA.NumOfChildrenInNeed = NumOfChildern
                USA.NumOfAdultsInNeed = NumOfAdults
                USA.Population = Population
                USA.NumOfPeopleNeededHelpPrevYear = NumOfPeopleNeededHelpPrevYear
                USA.UG = CDbl(InputBox("Enter the unemployement grant amount"))

                'upcasting
                Countries(NumCountry) = USA

        End Select

        TxtDisplay.Clear()

        'Polymorphism
        For c As Integer = 1 To NumCountry
            txtDisplay.Text &= Countries(c).Display & Environment.NewLine
        Next c

    End Sub

    'This will save to file
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        File = New FileStream(Filename, FileMode.Create, FileAccess.Write)
        BF = New BinaryFormatter

        'saving only one class
        For c As Integer = 1 To NumCountry
            Dim SA As SouthAfrica
            SA = TryCast(Countries(c), SouthAfrica)
            If Not (SA Is Nothing) Then
                BF.Serialize(File, SA)
            End If
        Next

        'when saving all the information
        'For h As Integer = 1 To NumCountry
        '    BF.Serialize(File, Countries(h))
        'Next h

        File.Close()
        MsgBox("All information is saved to file")

    End Sub

    'This will retrieve infomartion from the file
    Private Sub btnRead_Click(sender As Object, e As EventArgs) Handles btnRead.Click

        txtDisplay.Clear()
        File = New FileStream(Filename, FileMode.Open, FileAccess.Read)
        BF = New BinaryFormatter

        'reading From one class saved
        While File.Position < File.Length
            Dim SA As SouthAfrica

            SA = DirectCast(BF.Deserialize(File), SouthAfrica)

            txtDisplay.Text &= SA.Display & Environment.NewLine
        End While

        'reading all
        'While File.Position < File.Length

        '    Dim countries As Country
        '   countries  = DirectCast(BF.Deserialize(File), Country)


        '    txtDisplay.Text &=  countries.Display & Environment.NewLine


        'End While

        File.Close()


    End Sub
End Class
