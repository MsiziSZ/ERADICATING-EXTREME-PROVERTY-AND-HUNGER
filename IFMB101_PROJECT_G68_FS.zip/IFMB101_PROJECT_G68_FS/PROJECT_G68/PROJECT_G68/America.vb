﻿Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public Class America
    Inherits Country

    'Variable declaration
    Private _UG As Double

    'property methods
    Public Property UG() As Double
        Get
            Return _UG

        End Get
        Set(value As Double)

            _UG = value

        End Set
    End Property

    'constructor
    Public Sub New(name As String)
        MyBase.New(name)

    End Sub

    Public Overrides Function CalcAveragePeopleNotInNeed() As Double

        Return (CDbl(Population / (Population - NumOfAdultsInNeed - NumOfChildrenInNeed)))

    End Function

    Public Overrides Function DetermineTrend() As String
        Dim response As String
        If (NumOfPeopleNeededHelpPrevYear > (NumOfChildrenInNeed + NumOfAdultsInNeed)) Then
            response = "Extremely eradicating poverty"
        Else
            response = "Not eradicating poverty and hunger"
        End If

        Return response
    End Function

    Public Function CalcAveUGReceivers() As Double
        Return (CDbl(Population / (NumOfAdultsInNeed + NumOfChildrenInNeed)))

    End Function

    Public Overrides Function Display() As String
        Dim Tempdisplay As String

        Tempdisplay = "America" & Environment.NewLine
        Tempdisplay &= MyBase.Display
        Tempdisplay &= "Unemployement Grant :" & CStr(_UG) & Environment.NewLine
        Tempdisplay &= "Average People Not In Need :" & CStr(CalcAveragePeopleNotInNeed()) & Environment.NewLine
        Tempdisplay &= "Trend :" & CStr(DetermineTrend()) & Environment.NewLine
        Tempdisplay &= "Average UG Receivers:" & CStr(CalcAveUGReceivers()) & Environment.NewLine

        Return Tempdisplay
    End Function




End Class
